script_name("Command Binder")
script_author('Thomas_Lawson')
local limgui, imgui         = pcall(require, 'imgui')
local lencoding, encoding   = pcall(require, 'encoding')
assert(limgui, 'not found lib imgui')
assert(lencoding, 'not found lib encoding')
encoding.default = 'CP1251'
local u8 = encoding.UTF8

local vars = {
    menuselect  = 0,
    mainwindow  = imgui.ImBool(false),
    cmdbuf      = imgui.ImBuffer(256),
    cmdparams   = imgui.ImInt(0),
    cmdtext     = imgui.ImBuffer(20480)
}

local commands = {}

function scm(text)
    sampAddChatMessage(("[!] {FFFFFF}%s"):format(text), 0x8BC34A)
end

function apply_custom_style()
    imgui.SwitchContext()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local ImVec4 = imgui.ImVec4

    style.WindowRounding = 2.0
    style.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    style.ChildWindowRounding = 2.0
    style.FrameRounding = 2.0
    style.ItemSpacing = imgui.ImVec2(5.0, 4.0)
    style.ScrollbarSize = 13.0
    style.ScrollbarRounding = 0
    style.GrabMinSize = 8.0
    style.GrabRounding = 1.0

    colors[clr.FrameBg]                = ImVec4(0.16, 0.29, 0.48, 0.54)
    colors[clr.FrameBgHovered]         = ImVec4(0.26, 0.59, 0.98, 0.40)
    colors[clr.FrameBgActive]          = ImVec4(0.26, 0.59, 0.98, 0.67)
    colors[clr.TitleBg]                = ImVec4(0.04, 0.04, 0.04, 1.00)
    colors[clr.TitleBgActive]          = ImVec4(0.16, 0.29, 0.48, 1.00)
    colors[clr.TitleBgCollapsed]       = ImVec4(0.00, 0.00, 0.00, 0.51)
    colors[clr.CheckMark]              = ImVec4(0.26, 0.59, 0.98, 1.00)
    colors[clr.SliderGrab]             = ImVec4(0.24, 0.52, 0.88, 1.00)
    colors[clr.SliderGrabActive]       = ImVec4(0.26, 0.59, 0.98, 1.00)
    colors[clr.Button]                 = ImVec4(0.26, 0.59, 0.98, 0.40)
    colors[clr.ButtonHovered]          = ImVec4(0.26, 0.59, 0.98, 1.00)
    colors[clr.ButtonActive]           = ImVec4(0.06, 0.53, 0.98, 1.00)
    colors[clr.Header]                 = ImVec4(0.26, 0.59, 0.98, 0.31)
    colors[clr.HeaderHovered]          = ImVec4(0.26, 0.59, 0.98, 0.80)
    colors[clr.HeaderActive]           = ImVec4(0.26, 0.59, 0.98, 1.00)
    colors[clr.Separator]              = colors[clr.Border]
    colors[clr.SeparatorHovered]       = ImVec4(0.26, 0.59, 0.98, 0.78)
    colors[clr.SeparatorActive]        = ImVec4(0.26, 0.59, 0.98, 1.00)
    colors[clr.ResizeGrip]             = ImVec4(0.26, 0.59, 0.98, 0.25)
    colors[clr.ResizeGripHovered]      = ImVec4(0.26, 0.59, 0.98, 0.67)
    colors[clr.ResizeGripActive]       = ImVec4(0.26, 0.59, 0.98, 0.95)
    colors[clr.TextSelectedBg]         = ImVec4(0.26, 0.59, 0.98, 0.35)
    colors[clr.Text]                   = ImVec4(1.00, 1.00, 1.00, 1.00)
    colors[clr.TextDisabled]           = ImVec4(0.50, 0.50, 0.50, 1.00)
    colors[clr.WindowBg]               = ImVec4(0.06, 0.06, 0.06, 0.94)
    colors[clr.ChildWindowBg]          = ImVec4(1.00, 1.00, 1.00, 0.00)
    colors[clr.PopupBg]                = ImVec4(0.08, 0.08, 0.08, 0.94)
    colors[clr.ComboBg]                = colors[clr.PopupBg]
    colors[clr.Border]                 = ImVec4(0.43, 0.43, 0.50, 0.50)
    colors[clr.BorderShadow]           = ImVec4(0.00, 0.00, 0.00, 0.00)
    colors[clr.MenuBarBg]              = ImVec4(0.14, 0.14, 0.14, 1.00)
    colors[clr.ScrollbarBg]            = ImVec4(0.02, 0.02, 0.02, 0.53)
    colors[clr.ScrollbarGrab]          = ImVec4(0.31, 0.31, 0.31, 1.00)
    colors[clr.ScrollbarGrabHovered]   = ImVec4(0.41, 0.41, 0.41, 1.00)
    colors[clr.ScrollbarGrabActive]    = ImVec4(0.51, 0.51, 0.51, 1.00)
    colors[clr.CloseButton]            = ImVec4(0.41, 0.41, 0.41, 0.50)
    colors[clr.CloseButtonHovered]     = ImVec4(0.98, 0.39, 0.36, 1.00)
    colors[clr.CloseButtonActive]      = ImVec4(0.98, 0.39, 0.36, 1.00)
    colors[clr.PlotLines]              = ImVec4(0.61, 0.61, 0.61, 1.00)
    colors[clr.PlotLinesHovered]       = ImVec4(1.00, 0.43, 0.35, 1.00)
    colors[clr.PlotHistogram]          = ImVec4(0.90, 0.70, 0.00, 1.00)
    colors[clr.PlotHistogramHovered]   = ImVec4(1.00, 0.60, 0.00, 1.00)
    colors[clr.ModalWindowDarkening]   = ImVec4(0.80, 0.80, 0.80, 0.35)
end
apply_custom_style()

function main()
    if not doesDirectoryExist("moonloader/config") then createDirectory("moonloader/config") end
    repeat wait(0) until isSampAvailable()
    sampRegisterChatCommand("cbind", cbind)
    if doesFileExist("moonloader/config/cmdbinder.json") then
        local file = io.open('moonloader/config/cmdbinder.json', 'r')
        if file then
            commands = decodeJson(file:read('*a'))
        end
    end
    saveData(commands, "moonloader/config/cmdbinder.json")
    registerCommands()
    while true do wait(0)
        imgui.Process = vars.mainwindow.v
    end
end

function registerCommands()
    for k, v in pairs(commands) do
        if sampIsChatCommandDefined(v.cmd) then sampUnregisterChatCommand(v.cmd) end
        sampRegisterChatCommand(v.cmd, function(pam)
            lua_thread.create(function()
                local params = string.split(pam, " ", v.params)
                local cmdtext = v.text
                if #params < v.params then
                    local paramtext = ""
                    for i = 1, v.params do
                        paramtext = paramtext .. "[��������"..i.."] "
                    end
                    scm("�������: /"..v.cmd.." "..paramtext, -1)
                else
                    local keys = {}
                    for i = 1, v.params do
                        keys["{param:"..i.."}"] = params[i]
                    end
                    for k1, v1 in pairs(keys) do
                        cmdtext = cmdtext:gsub(k1, v1)
                    end
                    for line in cmdtext:gmatch('[^\r\n]+') do
                        if line:match("{wait:%d+}") then
                            wait(line:match("{wait:(%d+)}"))
                        else
                            sampSendChat(line)
                        end
                    end
                end
            end)
        end)
    end
end

function cbind()
    vars.mainwindow.v = not vars.mainwindow.v
end

function imgui.OnDrawFrame()
    if vars.mainwindow.v then
        local sX, sY = getScreenResolution()
        imgui.SetNextWindowPos(imgui.ImVec2(sX/2, sY/2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
        imgui.SetNextWindowSize(imgui.ImVec2(891, 380), imgui.Cond.FirstUseEver)
        imgui.Begin(u8 "������ ������", vars.mainwindow, imgui.WindowFlags.NoResize)
        imgui.BeginChild("##commandlist", imgui.ImVec2(170 ,320), true)
        for k, v in pairs(commands) do
            if imgui.Selectable(u8(("%s. /%s##%s"):format(k, v.cmd, k)), vars.menuselect == k) then 
                vars.menuselect     = k 
                vars.cmdbuf.v       = u8(v.cmd) 
                vars.cmdparams.v    = v.params
                vars.cmdtext.v      = u8(v.text)
            end
        end
        imgui.EndChild()
        imgui.SameLine()
        imgui.BeginChild("##commandsetting", imgui.ImVec2(700, 320), true)
        for k, v in pairs(commands) do
            if vars.menuselect == k then
                imgui.InputText(u8 "������� ���� �������", vars.cmdbuf)
                imgui.InputInt(u8 "������� ���-�� ���������� �������", vars.cmdparams, 0)
                imgui.InputTextMultiline(u8 "##cmdtext", vars.cmdtext, imgui.ImVec2(678, 200))
                imgui.TextWrapped(u8 "����� ����������: {param:1}, {param:2} � �.� (������������ � ������ �� ����� ���������)\n���� ��������: {wait:���-�� �����������} (������������ �� ����� ������)")
                if imgui.Button(u8 "��������� �������") then
                    sampUnregisterChatCommand(v.cmd)
                    v.cmd = u8:decode(vars.cmdbuf.v)
                    v.params = vars.cmdparams.v
                    v.text = u8:decode(vars.cmdtext.v)
                    saveData(commands, "moonloader/config/cmdbinder.json")
                    registerCommands()
                    scm("������� ���������")
                end
                imgui.SameLine()
                if imgui.Button(u8 "������� �������") then
                    imgui.OpenPopup(u8 "�������� �������##"..k)
                end
                if imgui.BeginPopupModal(u8 "�������� �������##"..k, _, imgui.WindowFlags.AlwaysAutoResize) then
                    imgui.SetCursorPosX(imgui.GetWindowWidth()/2 - imgui.CalcTextSize(u8 "�� ������������� ������ ������� �������?").x / 2)
                    imgui.Text(u8 "�� ������������� ������ ������� �������?")
                    if imgui.Button(u8 "�������##"..k, imgui.ImVec2(170, 20)) then
                        sampUnregisterChatCommand(v.cmd)
                        vars.menuselect     = 0
                        vars.cmdbuf.v       = ""
                        vars.cmdparams.v    = 0
                        vars.cmdtext.v      = ""
                        table.remove(commands, k)
                        saveData(commands, "moonloader/config/cmdbinder.json")
                        registerCommands()
                        scm("������� �������")
                        imgui.CloseCurrentPopup()
                    end
                    imgui.SameLine()
                    if imgui.Button(u8 "������##"..k, imgui.ImVec2(170, 20)) then
                        imgui.CloseCurrentPopup()
                    end
                    imgui.EndPopup()
                end
            end
        end
        imgui.EndChild()
        if imgui.Button(u8 "�������� �������", imgui.ImVec2(170, 20)) then
            table.insert(commands, {cmd = "", params = 0, text = ""})
            saveData(commands, "moonloader/config/cmdbinder.json")
        end
        imgui.End()
    end
end

function string.split(inputstr, sep, limit)
    if limit == nil then limit = 0 end
    if sep == nil then sep = "%s" end
    local t={} ; i=1
    for str in string.gmatch(inputstr, "([^"..sep.."]+)") do
        if i >= limit and limit > 0 then
            if t[i] == nil then
                t[i] = ""..str
            else
                t[i] = t[i]..sep..str
            end
        else
            t[i] = str
            i = i + 1
        end
    end
    return t
end

function saveData(table, path)
	if doesFileExist(path) then os.remove(path) end
    local sfa = io.open(path, "w")
    if sfa then
        sfa:write(encodeJson(table))
        sfa:close()
    end
end