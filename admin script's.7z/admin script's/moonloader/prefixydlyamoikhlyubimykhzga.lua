require 'lib.moonloader'

local sampev = require 'lib.samp.events'

local name = ""
function main()
    while not isSampAvailable() do wait(0) end
    local _, id = sampGetPlayerIdByCharHandle(playerPed)
	name = sampGetPlayerNickname(id)
    sampRegisterChatCommand('prefixma', function(param) 
        if(param:match("(%d+)")) then
            sampSendChat("/prefix " .. param .. " ��.������������� 00FF00")
        end
    end)
    sampRegisterChatCommand('prefixa', function(param) 
        if(param:match("(%d+)")) then
            sampSendChat("/prefix " .. param .. " ������������� 4B0082")
        end
    end)
    sampRegisterChatCommand('prefixsa', function(param) 
        if(param:match("(%d+)")) then
            sampSendChat("/prefix " .. param .. " ��.������������� FFD700")
        end
    end)
    sampRegisterChatCommand('prefixzga', function(param) 
        if(param:match("(%d+)")) then
            sampSendChat("/prefix " .. param .. " ���.����.�������������� " .. color())
        end
    end)
    sampRegisterChatCommand('prefixga', function(param) 
        if(param:match("(%d+)")) then
            sampSendChat("/prefix " .. param .. " �������-������������� " .. color())
        end
    end)


    while true do
        wait(0)
        
    end
end

function sampev.onServerMessage(color, text)
    if text:find("������������� " .. name) and text:find("������������� � �����") then
        local ip = sampGetCurrentServerAddress()
        local _, id = sampGetPlayerIdByCharHandle(playerPed)
        local mcolor = ""
        math.randomseed( os.time() )
        for i = 1, 6 do
            local b = math.random(1, 16)
            if b == 1 then
                mcolor = mcolor .. "A"
            end
            if b == 2 then
                mcolor = mcolor .. "B"
            end
            if b == 3 then
                mcolor = mcolor .. "C"
            end
            if b == 4 then
                mcolor = mcolor .. "D"
            end
            if b == 5 then
                mcolor = mcolor .. "E"
            end
            if b == 6 then
                mcolor = mcolor .. "F"
            end
            if b == 7 then
                mcolor = mcolor .. "0"
            end
            if b == 8 then
                mcolor = mcolor .. "1"
            end
            if b == 9 then
                mcolor = mcolor .. "2"
            end
            if b == 10 then
                mcolor = mcolor .. "3"
            end
            if b == 11 then
                mcolor = mcolor .. "4"
            end
            if b == 12 then
                mcolor = mcolor .. "5"
            end
            if b == 13 then
                mcolor = mcolor .. "6"
            end
            if b == 14 then
                mcolor = mcolor .. "7"
            end
            if b == 15 then
                mcolor = mcolor .. "8"
            end
            if b == 16 then
                mcolor = mcolor .. "9"
            end
        end
        if ip == "46.174.52.246" then 
            sampSendChat("/prefix " .. id .. " ���.����.�������������� " .. tostring(mcolor))
        else
            sampSendChat("/prefix " .. id .. " ���.����.�������������� " .. tostring(mcolor))
        end
    end
end

function color()
    mcolor = ""
    math.randomseed( os.time() )
    for i = 1, 6 do
        local b = math.random(1, 16)
        if b == 1 then
            mcolor = mcolor .. "A"
        end
        if b == 2 then
            mcolor = mcolor .. "B"
        end
        if b == 3 then
            mcolor = mcolor .. "C"
        end
        if b == 4 then
            mcolor = mcolor .. "D"
        end
        if b == 5 then
            mcolor = mcolor .. "E"
        end
        if b == 6 then
            mcolor = mcolor .. "F"
        end
        if b == 7 then
            mcolor = mcolor .. "0"
        end
        if b == 8 then
            mcolor = mcolor .. "1"
        end
        if b == 9 then
            mcolor = mcolor .. "2"
        end
        if b == 10 then
            mcolor = mcolor .. "3"
        end
        if b == 11 then
            mcolor = mcolor .. "4"
        end
        if b == 12 then
            mcolor = mcolor .. "5"
        end
        if b == 13 then
            mcolor = mcolor .. "6"
        end
        if b == 14 then
            mcolor = mcolor .. "7"
        end
        if b == 15 then
            mcolor = mcolor .. "8"
        end
        if b == 16 then
            mcolor = mcolor .. "9"
        end
    end
    return mcolor
end